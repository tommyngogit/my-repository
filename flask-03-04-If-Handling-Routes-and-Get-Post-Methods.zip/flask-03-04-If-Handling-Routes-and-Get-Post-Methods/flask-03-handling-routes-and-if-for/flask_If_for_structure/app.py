# Import Flask modules


# Create an object named app 



# Create a function named head which shows the massage as "This is my first conditions experience" in `index.html` 
# and assign to the route of ('/')



# Create a function named header which prints numbers elements of list one by one in `index.html` 
# and assign to the route of ('/')



# run this app in debug mode on your local.

