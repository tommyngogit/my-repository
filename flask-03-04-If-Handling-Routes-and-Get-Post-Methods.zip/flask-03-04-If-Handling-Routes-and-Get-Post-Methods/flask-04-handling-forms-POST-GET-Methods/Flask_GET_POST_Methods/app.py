# Import Flask modules


# Create an object named app



# create a function named "lcm" which calculates a least common multiple values of two numbers. 



# Create a function named `index` which uses template file named `index.html` 
# send two numbers as template variable to the app.py and assign route of no path ('/') 





# calculate sum of them using "lcm" function, then sent the result to the 
# "result.hmtl" file and assign route of path ('/calc'). 
# When the user comes directly "/calc" path, "Since this is a GET request, LCM has not been calculated" string returns to them with "result.html" file



# Add a statement to run the Flask application which can be debugged.
